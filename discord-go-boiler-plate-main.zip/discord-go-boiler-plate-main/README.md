# discord-go boiler plate 

Basic boiler plate code for discord-go bots.

